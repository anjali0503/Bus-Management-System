<?php

session_start();
header('location:adminpage.php');


$con = mysqli_connect('localhost','root','');


mysqli_select_db($con,'sessionpractical');

$bus_no = $_POST['bus_no'];
$total_seats = $_POST['total_seats'];
$added_on = $_POST['added_on'];




$q = " select * from addbus where bus_no = '$bus_no' && total_seats = '$total_seats' && AddedOn = '$added_on' ";


    $_SESSION['status'] = "bus added to bus list";
    $qy = " insert into addbus(bus_no , total_seats , AddedOn  ) values('$bus_no' , '$total_seats' , '$added_on' )";
    mysqli_query($con, $qy);
    
?>